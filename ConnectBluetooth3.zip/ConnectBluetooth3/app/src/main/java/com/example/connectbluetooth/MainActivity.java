package com.example.connectbluetooth;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.security.PrivateKey;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final int Request_Enable_BT = 0;
    private static final int Request_Discover_BT = 1;


    TextView mStatusBlueTv, mPairedTv;
    ImageView mBlueTv;
    Button mOnBtn, mOffbtn, mDiscoverBtn, mPairedBtn;
    BluetoothAdapter mBlueAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mStatusBlueTv = findViewById(R.id.statusBlueToothTv);
        mPairedBtn = findViewById(R.id.pairedBtn);
        mBlueTv = findViewById(R.id.bluetoothIv);
        mOnBtn = findViewById(R.id.onBtn);
        mOffbtn = findViewById(R.id.offBtn);
        mDiscoverBtn = findViewById(R.id.discoverableBtn);
        mPairedTv = findViewById(R.id.pairedTv);

        mBlueAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBlueAdapter == null) {
            mStatusBlueTv.setText("BlueTooth is not avaiable");
        } else {
            mStatusBlueTv.setText("BlueTooth is avaiable");
            if (mBlueAdapter.isEnabled()) {
                mBlueTv.setImageResource(R.drawable.ic_action_on);
            } else {
                mBlueTv.setImageResource(R.drawable.ic_action_off);

            }
            mOnBtn.setOnClickListener(new View.OnClickListener() {
                @SuppressLint("MissingPermission")
                @Override
                public void onClick(View view) {

                    if (!mBlueAdapter.isEnabled()) {
                        navigateToBluetoothSettings();
                    } else {
                        showToast("Bluetooth is already ON");
                    }

                }
            });
            mDiscoverBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (ActivityCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }
                    if (mBlueAdapter.isDiscovering()) {
                        showToast("Make your divice Discoverable");
                        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);

                    }
                }
            });
            mOffbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mBlueAdapter.isEnabled()) {
                        showToast("The Bluetooth is already Turned ON ");
                    } else {
                        navigateToBluetoothSettings();
                    }

                }
            });
            mPairedBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mBlueAdapter.isEnabled()) {
                        mPairedTv.setText("Paired Devices");
                        if (ActivityCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        Set<BluetoothDevice> devices = mBlueAdapter.getBondedDevices();
                        for (BluetoothDevice device : devices)
                            mPairedTv.append("Device:" + device.getName() + "," + device);

                    } else {
                        showToast("Turn On Bluetooth to get paired device");
                    }

                }
            });
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case Request_Enable_BT:
                if (resultCode == RESULT_OK) {
                    mBlueTv.setImageResource(R.drawable.ic_action_on);
                    showToast("Bluetooth is ON");
                } else {
                    showToast("Bluetooth is OFF");
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void navigateToBluetoothSettings() {
        Intent intent = new Intent();
        intent.setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
        startActivity(intent);
    }
}